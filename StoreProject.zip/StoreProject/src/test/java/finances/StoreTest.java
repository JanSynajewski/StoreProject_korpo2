package finances;

import impl.Product;
import impl.ProductRepositoryImpl;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class StoreTest {

    private Store store;
    private Product product;
    @BeforeEach
    void setUp() {
        store = new Store(new ProductRepositoryImpl());
        product = new Product("Ziemniaki", new Price(3, 60), 100);
    }

    @org.junit.jupiter.api.Test
    void productDeliveryIfExists() {
        //given
        store.productDelivery("Ziemniaki", new Price(3, 60), 100);
        //when
        store.productDelivery("Ziemniaki", new Price(3, 60), 50);
        //then
        String expected = "Ziemniaki, 3,60, 150\n";
        assertEquals(expected, store.toString());

    }

    @org.junit.jupiter.api.Test
    void productDeliveryIfNotExists() {
        //given
        store.productDelivery("Marchewka", new Price(4, 20), 20);
        //when
        store.productDelivery("Pietruszka", new Price(4, 80), 50);
        //then
        String expected = "Marchewka, 4,20, 20\nPietruszka, 4,80, 50\n";
        assertEquals(expected, store.toString());
    }


    @org.junit.jupiter.api.Test
    void productSaleIfExistAndEnoughAmount() {
        //given
        store.productDelivery(product.getName(), product.getPrice(), product.getAmount());
        //when
        store.productSale("Ziemniaki", 20);
        //then
        String expected = "Ziemniaki, 3,60, 80";
        assertEquals(expected, store.toString());

    }

    @org.junit.jupiter.api.Test
    void productSaleIfExistAndNotEnoughAmount() {
        store.productDelivery(product.getName(), product.getPrice(), product.getAmount());
        Exception ex = assertThrows(IllegalStateException.class, () -> store.productSale("Ziemniaki",200));
    }

    @org.junit.jupiter.api.Test
    void productSaleIfNotExist() {
        //given
        store.productDelivery(product.getName(), product.getPrice(), product.getAmount());
        Exception ex = assertThrows(IllegalStateException.class, () -> store.productSale("Chleb",20));
    }

    @org.junit.jupiter.api.Test
    void testToString() {
        store.productDelivery(product.getName(), product.getPrice(), product.getAmount());
        assertEquals("Ziemniaki, 3,60, 100", store.toString());
    }
}