package impl;

import api.ProductRepository;

import java.util.*;

public class ProductRepositoryImpl implements ProductRepository {

    private Map<String, Product> map;
    Product name;

    public ProductRepositoryImpl(){
        map = new HashMap<String, Product>();
    }


    @Override
    public Product findByName(String name) {
        return map.get(name);
    }

    @Override
    public boolean exists(String name) {
        return map.containsKey(name);
    }

    @Override
    public Product create(Product product) {
        String name = product.getName();
        if(map.containsKey(name)) {
            throw new IllegalStateException("Duplicate!");
        }
        map.put(name, product);
        return map.get(name);
    }

    @Override
    public Product update(Product product) {
        map.put(product.getName(), product);
        return map.get(product.getName());

    }

    @Override
    public void delete(String name) {
        map.remove(name);
    }

    @Override
    public Set<Product> findAll() {
        return new HashSet<Product>(map.values());
    }
}
